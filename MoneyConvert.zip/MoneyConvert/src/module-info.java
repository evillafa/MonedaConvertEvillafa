/**
 * 
 */
/**
 * 
 */
module MoneyConvert {
}