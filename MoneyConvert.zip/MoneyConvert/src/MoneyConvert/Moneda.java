package MoneyConvert;
import java.text.DecimalFormat;
import java.util.Scanner;  


public class Moneda {
	
	// codigo del desafio
	public static void main(String[] args) {  
        // Entrada Scanner  
        Scanner scanner = new Scanner(System.in);  
        // Mensaje del menu de opciones
        System.out.println("Challenge conversor de monedas Evillafa!");  
        // loop
        while (true) {  
            // Menu 
            System.out.println("\nMenu:");  
            System.out.println("\n========================");
            System.out.println("1--* Convertir USD a ARG");  
            System.out.println("2--* Convertir Arg a USD");  
            System.out.println("3--* Convertir USD a BRA");
            System.out.println("4--* Convertir BRA a USD");
            System.out.println("5--* Convertir USD a COL");
            System.out.println("6--* Convertir COL a USD");
            System.out.println("7--* Salir");  
            System.out.println("\n========================");
            System.out.print("Selecciona opcion : ");  
            
            // lee opcion seleccionada 
            int choice = scanner.nextInt();  
            // analiza cases
            switch (choice) {  
                case 1:  
                	ConvertirUSDaARG();  
                    break;  
                case 2:  
                    convertirARGToUSD();  
                    break;  
                case 3:
                	convertirUSDaReal();
                	break;
                case 4:
                	convertirRealaUSD();
                	break;
                case 5:
                	convertirUSDaCol();
                	break;
                case 6:
                	convertirColaUSD();
                	break;
                	
                case 7:  
                    System.out.println("Gracias por usa el convertido de monedas!");  
                    // cierra funcion de scanner  
                    scanner.close();  
                    return;  
                default:  
                    System.out.println("Seleccion no valida, intente de nuevo.");  
            }  
        }  
    }  
    // tasas
    private static double usdToArgRate = 908.73;  
    private static double argToUsdRate = 0.0011;  
    private static double usdToBraRate = 5.39;
    private static double BraTousdRate = 0.19;
    private static double usdToColRate = 4091.3;
    private static float ColtoUSDRate = (float) 0.00024;
    
    // convertir dolar a peso Arg  
    private static void ConvertirUSDaARG() {  
        Scanner scanner = new Scanner(System.in);  
        System.out.print("Escribe cantidad en USD: ");  
        double usdAmount = scanner.nextDouble();  
        double argAmount = usdAmount * usdToArgRate;  
        System.out.println(usdAmount + " USD es equivalente a " + argAmount + " ARG");  
    }  
    // conertir pesos ARG a dolares 
    private static void convertirARGToUSD() {  
        Scanner scanner = new Scanner(System.in);  
        System.out.print("Enter cantidad en  ARG: ");  
        double argAmount = scanner.nextDouble();  
        double usdAmount = argAmount * argToUsdRate;  
        System.out.println(argAmount + " ARG es equivalente a " + usdAmount + " USD");  
    }  
    
    // convertir dolar a reales brasileños
    private static void convertirUSDaReal() {
    	Scanner scanner = new Scanner(System.in);  
        System.out.print("Enter cantidad en  USD: ");  
        double usdAmount = scanner.nextDouble();  
        double braAmount = usdAmount * usdToBraRate;  
        System.out.println(usdAmount + " USD es equivalente a " + braAmount + " BRA"); 
		
	}
    //convertir reales brasileños a dolares
    private static void convertirRealaUSD() {
    	Scanner scanner = new Scanner(System.in);  
        System.out.print("Enter cantidad en  BRA: ");  
        double braAmount = scanner.nextDouble();  
        double usdAmount = braAmount * BraTousdRate;  
        System.out.println(braAmount + " BRA es equivalente a " + usdAmount + " USD");
    	
		
	}
    
    //convertir dolares a peso colombiano
    private static void convertirUSDaCol() {
    	
    	Scanner scanner = new Scanner(System.in);  
        System.out.print("Enter cantidad en  USD: ");  
        double usdAmount = scanner.nextDouble();  
        double colAmount = usdAmount * usdToColRate;  
        System.out.println(usdAmount + " USD es equivalente a " + colAmount + " COL");
		
	}
    
    //convertir peso colombiano a dolar
    private static void convertirColaUSD() {
    	//DecimalFormat formateador = new DecimalFormat("#0.00");
    	Scanner scanner = new Scanner(System.in);  
        System.out.print("Enter cantidad en  COL: ");  
        double 	colAmount = scanner.nextDouble();  
        double usdAmount = colAmount * ColtoUSDRate;  
        System.out.printf(colAmount + " COL es equivalente a " + usdAmount + " USD");
    	
		
	}

}
